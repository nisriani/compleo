import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MondayPage } from './monday.page';

describe('MondayPage', () => {
  let component: MondayPage;
  let fixture: ComponentFixture<MondayPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MondayPage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MondayPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

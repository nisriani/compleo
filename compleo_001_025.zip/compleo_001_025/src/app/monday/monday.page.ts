import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-monday',
  templateUrl: './monday.page.html',
  styleUrls: ['./monday.page.scss'],
})

export class MondayPage {

  constructor (public router:Router){}
  goSchedule(){
    this.router.navigate(['/schedule']);
  }
}

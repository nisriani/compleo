import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-tuesday',
  templateUrl: './tuesday.page.html',
  styleUrls: ['./tuesday.page.scss'],
})

export class TuesdayPage {

  constructor (public router:Router){}
  goSchedule(){
    this.router.navigate(['/schedule']);
  }
}

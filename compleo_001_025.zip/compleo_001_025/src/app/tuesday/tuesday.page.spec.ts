import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TuesdayPage } from './tuesday.page';

describe('TuesdayPage', () => {
  let component: TuesdayPage;
  let fixture: ComponentFixture<TuesdayPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TuesdayPage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TuesdayPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

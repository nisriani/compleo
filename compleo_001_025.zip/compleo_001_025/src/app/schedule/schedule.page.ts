import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-schedule',
  templateUrl: './schedule.page.html',
  styleUrls: ['./schedule.page.scss'],
})


export class SchedulePage {

  constructor (public router:Router){}
  goFeatures(){
    this.router.navigate(['/features']);
  }

  goMonday(){
    this.router.navigate(['/monday']);
  }

  goTuesday(){
    this.router.navigate(['/tuesday']);
  }

  goWednesday(){
    this.router.navigate(['/wednesday']);
  }

  goThursday(){
    this.router.navigate(['/thursday']);
  }

  goFriday(){
    this.router.navigate(['/friday']);
  }
}

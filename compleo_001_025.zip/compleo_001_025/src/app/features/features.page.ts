import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-features',
  templateUrl: './features.page.html',
  styleUrls: ['./features.page.scss'],
})
export class FeaturesPage {

  constructor (public router:Router){}
  goHome(){
    this.router.navigate(['/home']);
  }
  goHomework(){
    this.router.navigate(['/homework']);
  }
  goSchedule(){
    this.router.navigate(['/schedule']);
  }
  goActivity(){
    this.router.navigate(['/activity']);
  }
  goReminder(){
    this.router.navigate(['/reminder']);
  }

}

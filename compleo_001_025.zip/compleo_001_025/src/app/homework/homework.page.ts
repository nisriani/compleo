import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-homework',
  templateUrl: './homework.page.html',
  styleUrls: ['./homework.page.scss'],
})

export class HomeworkPage {

  constructor (public router:Router){}
  goFeatures(){
    this.router.navigate(['/features']);
  }

}

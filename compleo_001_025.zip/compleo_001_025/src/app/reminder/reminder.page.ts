import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-reminder',
  templateUrl: './reminder.page.html',
  styleUrls: ['./reminder.page.scss'],
})

export class ReminderPage {

  constructor (public router:Router){}
  goFeatures(){
    this.router.navigate(['/features']);
  }

}

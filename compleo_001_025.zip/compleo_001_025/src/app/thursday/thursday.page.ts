import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-thursday',
  templateUrl: './thursday.page.html',
  styleUrls: ['./thursday.page.scss'],
})

export class ThursdayPage {

  constructor (public router:Router){}
  goSchedule(){
    this.router.navigate(['/schedule']);
  }
}

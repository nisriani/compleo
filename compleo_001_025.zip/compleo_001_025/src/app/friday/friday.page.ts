import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-friday',
  templateUrl: './friday.page.html',
  styleUrls: ['./friday.page.scss'],
})

export class FridayPage {

  constructor (public router:Router){}
  goSchedule(){
    this.router.navigate(['/schedule']);
  }
}

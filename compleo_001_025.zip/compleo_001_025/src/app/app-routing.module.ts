import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  { path: 'home', loadChildren: './home/home.module#HomePageModule' },
  { path: 'features', loadChildren: './features/features.module#FeaturesPageModule' },
  { path: 'features', loadChildren: './features/features.module#FeaturesPageModule' },
  { path: 'homework', loadChildren: './homework/homework.module#HomeworkPageModule' },
  { path: 'schedule', loadChildren: './schedule/schedule.module#SchedulePageModule' },
  { path: 'activity', loadChildren: './activity/activity.module#ActivityPageModule' },
  { path: 'reminder', loadChildren: './reminder/reminder.module#ReminderPageModule' },
  { path: 'monday', loadChildren: './monday/monday.module#MondayPageModule' },
  { path: 'tuesday', loadChildren: './tuesday/tuesday.module#TuesdayPageModule' },
  { path: 'wednesday', loadChildren: './wednesday/wednesday.module#WednesdayPageModule' },
  { path: 'thursday', loadChildren: './thursday/thursday.module#ThursdayPageModule' },
  { path: 'friday', loadChildren: './friday/friday.module#FridayPageModule' },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }

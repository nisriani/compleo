import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-wednesday',
  templateUrl: './wednesday.page.html',
  styleUrls: ['./wednesday.page.scss'],
})

export class WednesdayPage {

  constructor (public router:Router){}
  goSchedule(){
    this.router.navigate(['/schedule']);
  }
}
